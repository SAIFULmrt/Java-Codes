public class Child2 extends Blueprint {

  void checkWaterTemp() {
    System.out.println("Water temperature is high");
  }

  void checkPlantStatus() {
    System.out.println("Plants are good");

  }

  void checkWaterDOD() {
    System.out.println("Water DOD is bad");
  }

  void checkWaterLevel() {
    System.out.println("Water level is too low");
  }

  void checkWaterTurbidity() {
    System.out.println("Water turbidity is not enough");
  }

  void checkWaterPH() {
    System.out.println("Water ph is in bad level");
  }
}
