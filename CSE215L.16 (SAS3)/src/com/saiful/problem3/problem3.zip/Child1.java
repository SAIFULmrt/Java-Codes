public class Child1 extends Blueprint {

  void checkWaterTemp() {
    System.out.println("Water temperature is high");
  }

  void checkPlantStatus() {
    System.out.println("Plants are good");

  }

  void checkWaterDOD() {
    System.out.println("Water DOD is 2.3");
  }

  void checkWaterLevel() {
    System.out.println("Wtaer level is 2.4 metre");
  }

  void checkWaterTurbidity() {
    System.out.println("Water turbidity is enough");
  }

  void checkWaterPH() {
    System.out.println("Water ph is in good level");
  }
}
