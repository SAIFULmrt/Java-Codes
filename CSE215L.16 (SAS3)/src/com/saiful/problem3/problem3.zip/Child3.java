public class Child3 extends Blueprint {

  void checkWaterTemp() {
    System.out.println("Water temperature iaverage");
  }

  void checkPlantStatus() {
    System.out.println("Plants are good");

  }

  void checkWaterDOD() {
    System.out.println("Water DOD is average");
  }

  void checkWaterLevel() {
    System.out.println("Water level is in right status");
  }

  void checkWaterTurbidity() {
    System.out.println("Water turbidity is not good enough");
  }

  void checkWaterPH() {
    System.out.println("Water ph is in too bad level");
  }
}
